//Ascii 
class AssmtArr4
{
public static void main(String[] args)
 {
   int arr[]= {65,66,67,68,125,124,100,150};
   for(int i=0;i<arr.length;i++)
   {
	System.out.print((char)arr[i]+" ");
   }
		
 }

}
